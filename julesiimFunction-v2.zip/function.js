exports.helloGCS = (req, res) => {
    console.log('Hello, World!');
    res.send('Hello, World!');
};
